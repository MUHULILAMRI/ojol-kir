<?php
$host = "sql123.infinityfree.com";
$dbname = "if0_42425773_ojolkir";
$username = "if0_42425773";
$password = "rwZSIOA3WdB3Gq";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi Database Gagal: " . $e->getMessage());
}
?>